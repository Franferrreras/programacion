package com.company;

public enum Puesto {administrativo,tecnico,directiva}