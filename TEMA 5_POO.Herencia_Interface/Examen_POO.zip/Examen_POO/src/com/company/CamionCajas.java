package com.company;

import java.util.Arrays;

public class CamionCajas extends Vehiculo implements Comparable<CamionCajas>{

    private Cajas[] caj;

    public CamionCajas(String matricula, double cargaMaxima, String conductor) {
        super(matricula, cargaMaxima, conductor);
        this.caj = new Cajas[0];
    }

    public CamionCajas(String matricula, String conductor) {
        super(matricula, conductor);
        this.caj = new Cajas[0];
    }


    public Cajas[] getCaj() {
        return caj;
    }

    public void setCaj(Cajas[] caj) {
        this.caj = caj;
    }

    public void addCaja(Cajas c) {
        if (caj != null) {
            if (caj.length <= cargaMaxima) {
                caj = Arrays.copyOf(caj,caj.length+1);
                caj[caj.length-1] = c;
            }else {
                System.out.println("El camion esta lleno");
            }
        }else {
            caj = new Cajas[1];
            caj[0] = c;
        }
    }

    public void removeCaja(Cajas c1) {
        Cajas[] resultado;
        int contdelete =0;
        for (int i = 0; i < caj.length ; i++) {
            if (!caj[i].getId().equals(c1.getId())) {
                contdelete++;
            }
        }
        resultado = new Cajas[contdelete];

        int cont=0;
        for (int i = 0; i < caj.length ; i++) {
            if (!caj[i].getId().equals(c1.getId())) {
                resultado[cont] = caj[i];
                cont++;
            }
        }
        caj = resultado;
    }

    public void mostrarCarga(){
        System.out.println(Arrays.deepToString(caj));
    }
    @Override
    public void descarga() {
        System.out.println("Descarganado"+Arrays.toString(caj));
        for (int i = 0; i <caj.length ; i++) {
            System.out.println("y decargando "+caj[i]);
        }
    }

    @Override
    public int compareTo(CamionCajas o) {
        return caj.length-o.getCaj().length;
    }

    
    @Override
    public String toString() {
        return "CamionCajas{" +
                "caj=" + Arrays.toString(caj) +
                ", matricula='" + matricula + '\'' +
                ", cargaMaxima=" + cargaMaxima +
                ", conductor='" + conductor + '\'' +
                ",numeroCajas= "+caj.length+
                '}';
    }
}
