package com.company;

public abstract class Vehiculo {

    protected String matricula;
    protected double cargaMaxima;
    protected String conductor;

    public Vehiculo(String matricula, double cargaMaxima, String conductor) {
        this.matricula = matricula;
        this.cargaMaxima = cargaMaxima;
        this.conductor = conductor;
    }

    public Vehiculo(String matricula, String conductor) {
        this(matricula,5,conductor);
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public double getCargaMaxima() {
        return cargaMaxima;
    }

    public void setCargaMaxima(double cargaMaxima) {
        this.cargaMaxima = cargaMaxima;
    }

    public String getConductor() {
        return conductor;
    }

    public void setConductor(String conductor) {
        this.conductor = conductor;
    }

    public abstract void descarga();

    @Override
    public String toString() {
        return "Vehiculo{" +
                "matricula='" + matricula + '\'' +
                ", cargaMaxima=" + cargaMaxima +
                ", conductor='" + conductor + '\'' +
                '}';
    }
}
