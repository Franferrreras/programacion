package com.company;

public interface Colgar {

    public void colgar();
}
