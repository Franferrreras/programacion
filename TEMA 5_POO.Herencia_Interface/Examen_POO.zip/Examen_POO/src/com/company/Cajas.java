package com.company;

import java.util.Arrays;

public class Cajas {

    private String id;
    private boolean transportada;
    private int capcMaxima;
    private Prendas[] prend;

    public Cajas(String id, boolean transportada, int capcMaxima) {
        this.id = id;
        this.transportada = transportada;
        if (transportada = true) {
            this.capcMaxima = 5;
        }else {
            this.capcMaxima = capcMaxima;
        }
        this.prend = new Prendas[0];
    }

    public Cajas(String id) {
        this(id,true,5);
        this.prend = new Prendas[0];
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isTransportada() {
        return transportada;
    }

    public void setTransportada(boolean transportada) {
        this.transportada = transportada;
    }

    public int getCapcMaxima() {
        return capcMaxima;
    }

    public void setCapcMaxima(int capcMaxima) {
        this.capcMaxima = capcMaxima;
    }

    public Prendas[] getPrend() {
        return prend;
    }

    public void setPrend(Prendas[] prend) {
        this.prend = prend;
    }

    public void addPrendas(Prendas p) {
        if (prend != null) {
            if (transportada) {
                if (prend.length <=capcMaxima) {
                  prend = Arrays.copyOf(prend,prend.length+1);
                  prend[prend.length-1] = p;
                }else {
                    System.out.println("La caja esta llena");
                }
            }
        }else {
            prend = new Prendas[1];
            prend[0] = p;
        }
    }

    public void removePrendas(Prendas pr) {
        int tam=0;
        for (int i = 0; i < prend.length ; i++) {
            if (!prend[i].equals(pr.getCodBarra())) {
                tam++;
            }
        }

        Prendas[] resultado = new Prendas[tam];

        int cont = 0;
        for (int i = 0; i < prend.length ; i++) {
            if (!prend[i].getCodBarra().equals(pr.getCodBarra())) {
                resultado[cont] = prend[i];
                cont++;
            }
        }

        prend = resultado;
    }

    public void mostrarPrendas() {
        System.out.println(Arrays.toString(prend));
    }


    @Override
    public String toString() {
        return "Cajas{" +
                "id='" + id + '\'' +
                ", transportada=" + transportada +
                ", capcMaxima=" + capcMaxima +
                ", prend=" + Arrays.toString(prend) +
                '}';
    }
}
