package com.company;

import java.util.Arrays;
import java.util.Comparator;

public class Main {

    public static void main(String[] args) {
	// write your code here

        CamionCajas cm = new CamionCajas("7723DNJ",40,"Pedro");
        CamionCajas cm1 = new CamionCajas("4723DNJ",20,"Lazaro");
        CamionCajas cm2 = new CamionCajas("9723DNJ",10,"Herrera");

        CamionPerchas cp = new CamionPerchas("63464V",10,"Fernando");
        CamionPerchas cp1 = new CamionPerchas("73464V",10,"Cernando");
        CamionPerchas cp2 = new CamionPerchas("93464V",10,"Kernando");

        Cajas c1 = new Cajas("46464j");
        Cajas c2 = new Cajas("56464j");
        Cajas c3 = new Cajas("76464j");

        Prendas pr = new Prendas(29.99,"Vestido","X83945");
        Prendas pr1 = new Prendas(19.99,"pantalon","J83945");
        Prendas pr2 = new Prendas(49.99,"Abrigo","V83945");
        Prendas colgada1 = new Prendas(49.99,"Abrigo","V85945",10,true,3);
        Prendas colgada2 = new Prendas(39.99,"Vestodp","TF3945",10,true,3);
        Prendas colgada3 = new Prendas(39.99,"Vestodp","TF3945",10,true,3);


        cp.addPrendaColgada(colgada1);
        cp.addPrendaColgada(colgada2);
        cp.mostrarCamoinPerchas();
        cp.removePrendaColgada(colgada2);
        cp.mostrarCamoinPerchas();
        cp.descarga();
        cp1.addPrendaColgada(colgada1);
        cp1.addPrendaColgada(colgada2);
        cp1.addPrendaColgada(colgada3);


        cm.addCaja(c1);
        cm.addCaja(c3);
        cm1.addCaja(c1);
        cm1.addCaja(c2);
        cm1.addCaja(c3);


        c1.addPrendas(pr);
        c1.addPrendas(pr2);
        c1.mostrarPrendas();
        c1.removePrendas(pr);
        c1.mostrarPrendas();


        cm.mostrarCarga();
        cm.removeCaja(c3);
        cm.mostrarCarga();
        cm.descarga();


        //ordenando camiones por defecto, numero de cajas
        CamionCajas[] camionesCajas = new CamionCajas[3];
        camionesCajas[0] = cm;
        camionesCajas[1] = cm1;
        camionesCajas[2] = cm2;
        Arrays.sort(camionesCajas);
        System.out.println(Arrays.toString(camionesCajas));

        //ordenando camoines por la carga maxima
        Arrays.sort(camionesCajas, new Comparator<CamionCajas>() {
            @Override
            public int compare(CamionCajas camionCajas, CamionCajas t1) {
                return (int) (camionCajas.cargaMaxima-t1.cargaMaxima);
            }
        });

        System.out.println(Arrays.toString(camionesCajas));


        //ordenando camiones perchas
        CamionPerchas[] Camionesperchas = new CamionPerchas[3];
        Camionesperchas[0] = cp;
        Camionesperchas[1] = cp1;
        Camionesperchas[2] = cp2;
        Arrays.sort(Camionesperchas);
        System.out.println(Arrays.toString(Camionesperchas));

    }


    //mostrar precio prendas
}
