package com.company;

public interface Doblar {

    public void doblar();
}
