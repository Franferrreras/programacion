package com.company;

public interface Devolver {

    public void devolver();
}
