package com.company;

import java.util.Arrays;

public class CamionPerchas extends Vehiculo implements Comparable<CamionPerchas>{

    Prendas[] prendasColgadas;


    public CamionPerchas(String matricula, double cargaMaxima, String conductor) {
        super(matricula, cargaMaxima, conductor);
        this.prendasColgadas = new Prendas[0];
    }

    public CamionPerchas(String matricula, String conductor) {
        super(matricula, conductor);
        this.prendasColgadas = new Prendas[0];
    }


    public Prendas[] getPrendasColgadas() {
        return prendasColgadas;
    }

    public void setPrendasColgadas(Prendas[] prendasColgadas) {
        this.prendasColgadas = prendasColgadas;
    }


    public void addPrendaColgada(Prendas p) {

        if (prendasColgadas != null) {

            if (prendasColgadas.length <= getCargaMaxima()) {
                if (p.isPrendaColgada()) {
                    prendasColgadas = Arrays.copyOf(prendasColgadas, prendasColgadas.length + 1);
                    prendasColgadas[prendasColgadas.length - 1] = p;
                } else {
                    System.out.println("La prenda no se puede guardar ya que no es una prenda colgada");
                }
            } else {
                System.out.println("El CamionPerchas esta lleno");
            }
        } else {
            prendasColgadas = new Prendas[1];
            prendasColgadas[0] = p;
        }
    }

    public void removePrendaColgada(Prendas pr) {
        int tam = 0;
        for (int i = 0; i < prendasColgadas.length ; i++) {
            if (!prendasColgadas[i].getCodBarra().equals(pr.getCodBarra())) {
                tam++;
            }
        }
        Prendas[] resultado = new Prendas[tam];

        int cont = 0;
        for (int i = 0; i < prendasColgadas.length; i++) {
            if (!prendasColgadas[i].getCodBarra().equals(pr.getCodBarra())) {
                resultado[0] = prendasColgadas[i];
                cont++;
            }
        }
        prendasColgadas = resultado;
    }

    public void mostrarCamoinPerchas() {
        System.out.println(Arrays.toString(prendasColgadas));
    }

    @Override
    public void descarga() {
        System.out.println("Descargando "+Arrays.toString(prendasColgadas));
    }

    @Override
    public int compareTo(CamionPerchas o) {
        return getPrendasColgadas().length -o.prendasColgadas.length;
    }

    @Override
    public String toString() {
        return "CamionPerchas{" +
                "prendasColgadas=" + Arrays.toString(prendasColgadas) +
                ", matricula='" + matricula + '\'' +
                ", cargaMaxima=" + cargaMaxima +
                ", conductor='" + conductor + '\'' +
                "numeroPrendas= "+prendasColgadas.length+
                '}';
    }
}
