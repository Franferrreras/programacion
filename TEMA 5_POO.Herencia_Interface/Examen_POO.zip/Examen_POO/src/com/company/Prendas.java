package com.company;

public class Prendas implements Devolver, Colgar, Doblar{

    private double precio;
    private String nombre;
    private String codBarra;
    private double peso;
    private boolean prendaColgada;
    private double alturaPercha;

    public Prendas(double precio, String nombre, String codBarra, double peso, boolean prendaColgada, double alturaPercha) {
        this.precio = precio;
        this.nombre = nombre;
        this.codBarra = codBarra;
        this.peso = peso;
        this.prendaColgada = prendaColgada;
        if (prendaColgada = true) {
            this.alturaPercha = alturaPercha;
        }else {
            this.alturaPercha=0;
        }
    }

    public Prendas(double precio, String nombre, String codBarra) {
       this(precio,nombre,codBarra,10,false,0);
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodBarra() {
        return codBarra;
    }

    public void setCodBarra(String codBarra) {
        this.codBarra = codBarra;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public boolean isPrendaColgada() {
        return prendaColgada;
    }

    public void setPrendaColgada(boolean prendaColgada) {
        this.prendaColgada = prendaColgada;
    }

    public double getAlturaPercha() {
        return alturaPercha;
    }

    public void setAlturaPercha(double alturaPercha) {
        this.alturaPercha = alturaPercha;
    }

    @Override
    public void devolver() {
        System.out.println("Devolviendo la prenda "+getNombre()+" de precio"+getPrecio());
    }

    @Override
    public void colgar() {

    }

    @Override
    public void doblar() {
        if (prendaColgada=true)  {
            System.out.println("Esta prenda"+ getNombre()+"no se puede doblar");
        }else {
            System.out.println("Doblando prenda");
        }
    }
    @Override
    public String toString() {
        return "Prendas{" +
                "precio=" + precio +
                ", nombre='" + nombre + '\'' +
                ", codBarra='" + codBarra + '\'' +
                ", peso=" + peso +
                ", prendaColgada=" + prendaColgada +
                ", alturaPercha=" + alturaPercha +
                '}';
    }



}
